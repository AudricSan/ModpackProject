// REMOVE
onEvent('recipes', e => {
    // @collapse

    e.shapeless('9x kubejs:dust_dust', 'exnihilosequentia:dust')
})