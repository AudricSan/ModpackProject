onEvent('fluid.registry', event => {
    event.create('molten_craunium')
        .textureThick(0x5f5a98)
        .bucketColor(0x5f5a98)
        .displayName('Molten Craunium')
})