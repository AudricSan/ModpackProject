events.listen('item.tags', function (e) {
    e.remove('forge:ingots/silver', 'tconstruct:cobalt_ingot')
})