onEvent('worldgen.remove', event => {
    event.removeOres(ores => {
        ores.blocks = ['libvulpes:oredilithium', 'libvulpes:orealuminum']
        ores.biomes.values = []
    })
})