onEvent('recipes', e => {
    // @collapse

    e.shapeless('9x kubejs:dust_dust', 'exnihilosequentia:dust')
    e.shapeless('exnihilosequentia:dust', '9x kubejs:dust_dust')
})